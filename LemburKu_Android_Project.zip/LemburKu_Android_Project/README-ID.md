# LemburKu — proyek Android awal

Proyek Android native Kotlin + Jetpack Compose. Versi awal ini berisi kalkulator lembur offline dan unit test untuk kelompok jam 1, 2, 3, 8, dan 9.

## Penting
Ini adalah **proyek sumber**, bukan file APK yang sudah dikompilasi. APK dibangun melalui GitHub Actions di cloud.

## Cara build lewat HP (GitHub Actions)
1. Buat repository GitHub baru bernama `LemburKu`.
2. Unggah seluruh isi folder ZIP ini ke repository (jangan unggah ZIP sebagai satu file; ekstrak dahulu).
3. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build LemburKu APK**, lalu tekan **Run workflow**. Jika tab Actions tidak muncul, buka Settings → Actions dan izinkan workflow.
6. Tunggu workflow selesai dengan status hijau.
7. Buka hasil run dan unduh artifact bernama `LemburKu-debug-apk`.
8. Ekstrak artifact ZIP, lalu instal `app-debug.apk` di HP. Android mungkin meminta izin untuk memasang aplikasi dari sumber tersebut.

## Fitur versi awal
- Tema gelap.
- Input gaji pokok bulanan.
- Input jam mulai, jam selesai, dan istirahat dalam menit.
- Durasi melewati tengah malam didukung.
- Tarif berjenjang: 1–2 jam × 1,33; jam 3–8 × 1,66; jam 9+ × 2,66.
- Unit test perhitungan dasar.

## Belum tersedia di versi awal
- Penyimpanan riwayat permanen.
- Login lokal.
- Kalender hari libur resmi Taiwan.
- Aturan tarif yang berbeda per kategori hari/periode.
- Aturan uang makan.
- Ekspor CSV.
Fitur-fitur tersebut perlu ditambahkan dan diuji sebelum versi final dipakai sebagai kalkulator penggajian.

## Catatan akurasi
Rumus ini mengikuti pengali awal yang diberikan pengguna, bukan verifikasi hukum lengkap atas seluruh ketentuan upah lembur Taiwan. Periksa aturan perusahaan dan hukum yang berlaku sebelum mengandalkan hasil untuk penggajian resmi.
