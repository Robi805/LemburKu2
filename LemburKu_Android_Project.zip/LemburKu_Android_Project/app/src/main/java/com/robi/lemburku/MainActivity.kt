package com.robi.lemburku

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF1B1B1B)
private val Accent = Color(0xFF69D98B)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFFB8B8B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LemburKuScreen() }
    }
}

data class OvertimeResult(
    val netHours: Double,
    val firstTier: Double,
    val secondTier: Double,
    val thirdTier: Double,
    val firstPay: Double,
    val secondPay: Double,
    val thirdPay: Double,
    val totalPay: Double
)

object LemburCalculator {
    fun calculate(monthlySalary: Double, hours: Double, hourlyMultipliers: Triple<Double, Double, Double> = Triple(1.33, 1.66, 2.66)): OvertimeResult {
        require(monthlySalary >= 0.0) { "Gaji tidak boleh negatif." }
        require(hours >= 0.0) { "Jam lembur tidak boleh negatif." }
        val hourly = monthlySalary / 30.0 / 8.0
        val h1 = minOf(hours, 2.0)
        val h2 = max(0.0, minOf(hours - 2.0, 6.0))
        val h3 = max(0.0, hours - 8.0)
        val p1 = h1 * hourly * hourlyMultipliers.first
        val p2 = h2 * hourly * hourlyMultipliers.second
        val p3 = h3 * hourly * hourlyMultipliers.third
        return OvertimeResult(hours, h1, h2, h3, p1, p2, p3, p1 + p2 + p3)
    }
}

@Composable
fun LemburKuScreen() {
    var salary by remember { mutableStateOf("28590") }
    var start by remember { mutableStateOf("18:00") }
    var end by remember { mutableStateOf("20:00") }
    var breakMinutes by remember { mutableStateOf("0") }
    var dayType by remember { mutableStateOf("Hari kerja") }
    var error by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<OvertimeResult?>(null) }

    val money = remember { NumberFormat.getNumberInstance(Locale.US).apply { maximumFractionDigits = 0 } }
    fun moneyText(value: Double) = "NT$ ${money.format(value)}"

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = White, onSurface = White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("LemburKu", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Accent)
            Text("Kalkulator jam dan upah lembur", color = Muted)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("DATA PERHITUNGAN", color = Accent, fontWeight = FontWeight.Bold)
                    LemburField("Gaji pokok bulanan (NT$)", salary, { salary = it }, true)
                    Text("Kategori hari", color = Muted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Hari kerja", "Sabtu", "Minggu/libur").forEach { option ->
                            FilterChip(
                                selected = dayType == option,
                                onClick = { dayType = option },
                                label = { Text(option, fontSize = 12.sp) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { LemburField("Mulai (HH:mm)", start, { start = it }, false) }
                        Box(Modifier.weight(1f)) { LemburField("Selesai (HH:mm)", end, { end = it }, false) }
                    }
                    LemburField("Istirahat yang dipotong (menit)", breakMinutes, { breakMinutes = it }, true)
                    Button(
                        onClick = {
                            try {
                                error = ""
                                val salaryValue = salary.toDouble()
                                val breakValue = breakMinutes.toInt()
                                require(breakValue >= 0) { "Istirahat tidak boleh negatif." }
                                val startMinutes = parseTime(start)
                                var endMinutes = parseTime(end)
                                if (endMinutes < startMinutes) endMinutes += 24 * 60
                                val grossMinutes = endMinutes - startMinutes
                                val netMinutes = grossMinutes - breakValue
                                require(netMinutes >= 0) { "Istirahat melebihi durasi kerja." }
                                val hours = netMinutes / 60.0
                                result = LemburCalculator.calculate(salaryValue, hours)
                            } catch (e: Exception) {
                                error = e.message ?: "Periksa kembali input."
                                result = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                    ) {
                        Text("HITUNG UPAH LEMBUR", fontWeight = FontWeight.Bold)
                    }
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80))
                }
            }

            result?.let { r ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("HASIL PERHITUNGAN", color = Accent, fontWeight = FontWeight.Bold)
                        Text("${"%.2f".format(Locale.US, r.netHours)} jam bersih", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        HorizontalDivider(color = Color.DarkGray)
                        ResultLine("Jam 1–2 × 1,33", "${"%.2f".format(Locale.US, r.firstTier)} jam", moneyText(r.firstPay))
                        ResultLine("Jam 3–8 × 1,66", "${"%.2f".format(Locale.US, r.secondTier)} jam", moneyText(r.secondPay))
                        ResultLine("Jam 9+ × 2,66", "${"%.2f".format(Locale.US, r.thirdTier)} jam", moneyText(r.thirdPay))
                        HorizontalDivider(color = Color.DarkGray)
                        Text("TOTAL UPAH LEMBUR", color = Muted, fontSize = 13.sp)
                        Text(moneyText(r.totalPay), color = Accent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("Kategori dipilih: $dayType. Versi awal memakai pengali yang sama untuk semua kategori; aturan khusus per kategori belum diterapkan.", color = Muted, fontSize = 12.sp)
                    }
                }
            }

            Text("Versi awal • Offline • Tarif dapat dikembangkan melalui pengaturan", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun LemburField(label: String, value: String, onValueChange: (String) -> Unit, numeric: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Muted, fontSize = 13.sp)
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = White, unfocusedTextColor = White,
                focusedBorderColor = Accent, unfocusedBorderColor = Color.DarkGray,
                cursorColor = Accent
            )
        )
    }
}

@Composable
private fun ResultLine(label: String, hours: String, pay: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(label, color = White, fontSize = 14.sp)
            Text(hours, color = Muted, fontSize = 12.sp)
        }
        Text(pay, color = White, fontWeight = FontWeight.SemiBold)
    }
}

private fun parseTime(value: String): Int {
    val parts = value.trim().split(":")
    require(parts.size == 2) { "Format jam harus HH:mm, contoh 18:00." }
    val h = parts[0].toInt()
    val m = parts[1].toInt()
    require(h in 0..23 && m in 0..59) { "Jam tidak valid. Gunakan format HH:mm." }
    return h * 60 + m
}
