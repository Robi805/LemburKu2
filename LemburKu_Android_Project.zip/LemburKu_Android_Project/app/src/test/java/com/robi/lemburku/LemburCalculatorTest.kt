package com.robi.lemburku

import org.junit.Assert.assertEquals
import org.junit.Test

class LemburCalculatorTest {
    @Test fun oneHour() {
        val r = LemburCalculator.calculate(24000.0, 1.0)
        assertEquals(1.0, r.firstTier, 0.0001)
        assertEquals(0.0, r.secondTier, 0.0001)
    }
    @Test fun twoHours() {
        val r = LemburCalculator.calculate(24000.0, 2.0)
        assertEquals(2.0, r.firstTier, 0.0001)
    }
    @Test fun threeHours() {
        val r = LemburCalculator.calculate(24000.0, 3.0)
        assertEquals(2.0, r.firstTier, 0.0001)
        assertEquals(1.0, r.secondTier, 0.0001)
    }
    @Test fun eightHours() {
        val r = LemburCalculator.calculate(24000.0, 8.0)
        assertEquals(6.0, r.secondTier, 0.0001)
        assertEquals(0.0, r.thirdTier, 0.0001)
    }
    @Test fun nineHours() {
        val r = LemburCalculator.calculate(24000.0, 9.0)
        assertEquals(1.0, r.thirdTier, 0.0001)
    }
}
